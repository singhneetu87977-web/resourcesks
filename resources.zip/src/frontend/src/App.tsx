import { Toaster } from "@/components/ui/sonner";
import CircleGame from "./components/CircleGame";
import EducationSection from "./components/EducationSection";
import Footer from "./components/Footer";
import HeroSection from "./components/HeroSection";
import Navbar from "./components/Navbar";
import ResourcesSection from "./components/ResourcesSection";

export default function App() {
  return (
    <div className="grain min-h-screen bg-background">
      <Navbar />
      <main>
        <HeroSection />
        <EducationSection />
        <ResourcesSection />
        <CircleGame />
      </main>
      <Footer />
      <Toaster
        theme="dark"
        toastOptions={{
          style: {
            background: "oklch(0.15 0.008 270)",
            border: "1px solid oklch(0.25 0.01 270)",
            color: "oklch(0.96 0.005 80)",
          },
        }}
      />
    </div>
  );
}
