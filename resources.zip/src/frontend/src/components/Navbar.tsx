import { BookOpen } from "lucide-react";
import { motion } from "motion/react";

export default function Navbar() {
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <motion.header
      initial={{ y: -80, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="fixed top-0 left-0 right-0 z-50 px-6 py-4"
    >
      <div className="max-w-7xl mx-auto flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gold-400 flex items-center justify-center">
            <BookOpen className="w-4 h-4 text-background" strokeWidth={2.5} />
          </div>
          <span className="font-display font-bold text-xl text-gradient-gold tracking-tight">
            Resources
          </span>
        </div>

        <nav className="glass-card rounded-full px-2 py-2 flex items-center gap-1">
          <button
            type="button"
            data-ocid="nav.home.link"
            onClick={() => scrollTo("hero")}
            className="px-4 py-1.5 rounded-full text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-white/5 transition-all"
          >
            Home
          </button>
          <button
            type="button"
            data-ocid="nav.resources.link"
            onClick={() => scrollTo("resources")}
            className="px-4 py-1.5 rounded-full text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-white/5 transition-all"
          >
            Resources
          </button>
          <button
            type="button"
            data-ocid="nav.game.link"
            onClick={() => scrollTo("game")}
            className="px-4 py-1.5 rounded-full text-sm font-medium text-background bg-gold-400 hover:bg-gold-300 transition-all"
          >
            Game
          </button>
        </nav>
      </div>
    </motion.header>
  );
}
