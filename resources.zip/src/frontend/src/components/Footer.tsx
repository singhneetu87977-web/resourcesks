import { BookOpen, Heart } from "lucide-react";

export default function Footer() {
  const year = new Date().getFullYear();
  const utm = `https://caffeine.ai?utm_source=caffeine-footer&utm_medium=referral&utm_content=${encodeURIComponent(typeof window !== "undefined" ? window.location.hostname : "")}`;

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <footer className="py-12 px-6 border-t border-border">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-gold-400 flex items-center justify-center">
            <BookOpen
              className="w-3.5 h-3.5 text-background"
              strokeWidth={2.5}
            />
          </div>
          <span className="font-display font-bold text-lg text-gradient-gold">
            Resources
          </span>
        </div>

        <p className="text-sm text-muted-foreground flex items-center gap-1.5">
          © {year}. Built with
          <Heart className="w-3.5 h-3.5 text-gold-400 fill-gold-400" />
          using{" "}
          <a
            href={utm}
            target="_blank"
            rel="noopener noreferrer"
            className="text-gold-400 hover:text-gold-300 transition-colors"
          >
            caffeine.ai
          </a>
        </p>

        <div className="flex items-center gap-6 text-sm text-muted-foreground">
          <button
            type="button"
            onClick={() => scrollTo("hero")}
            className="hover:text-foreground transition-colors"
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => scrollTo("resources")}
            className="hover:text-foreground transition-colors"
          >
            Resources
          </button>
          <button
            type="button"
            onClick={() => scrollTo("game")}
            className="hover:text-foreground transition-colors"
          >
            Game
          </button>
        </div>
      </div>
    </footer>
  );
}
